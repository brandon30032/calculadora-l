import { useState } from 'react'

const percentages = [10, 15, 20]

function formatMoney(value) {
  return new Intl.NumberFormat('es-HN', {
    style: 'currency',
    currency: 'HNL',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(value)
}

export default function App() {
  const [bill, setBill] = useState('')
  const [tipPercent, setTipPercent] = useState(15)
  const [calculated, setCalculated] = useState(false)

  const billAmount = Number(bill)
  const validBill = bill.trim() !== '' && Number.isFinite(billAmount) && billAmount > 0
  const tipAmount = validBill ? billAmount * (tipPercent / 100) : 0
  const totalAmount = validBill ? billAmount + tipAmount : 0

  function calculateTip(event) {
    event.preventDefault()
    if (validBill) setCalculated(true)
    else setCalculated(false)
  }

  function handleBillChange(event) {
    setBill(event.target.value)
    setCalculated(false)
  }

  function handlePercentChange(percent) {
    setTipPercent(percent)
    setCalculated(false)
  }

  function resetCalculator() {
    setBill('')
    setTipPercent(15)
    setCalculated(false)
  }

  return (
    <main className="min-h-screen px-4 py-10 sm:px-6 flex items-center justify-center">
      <section className="w-full max-w-lg">
        <div className="mb-7 text-center">
          <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-emerald-400/15 text-3xl shadow-lg">
            🍽️
          </div>
          <p className="mb-2 text-sm font-semibold uppercase tracking-[0.2em] text-emerald-300">Herramienta sencilla</p>
          <h1 className="text-3xl font-extrabold tracking-tight text-white sm:text-4xl">Calculadora de Propinas</h1>
          <p className="mt-3 text-slate-400">Calcula la propina y el total de tu cuenta en segundos.</p>
        </div>

        <div className="rounded-3xl border border-slate-700/70 bg-slate-900/90 p-6 shadow-2xl sm:p-8">
          <form onSubmit={calculateTip} className="space-y-6">
            <div>
              <label htmlFor="bill" className="mb-2 block text-sm font-semibold text-slate-200">
                Total de la cuenta (L)
              </label>
              <div className="relative">
                <span className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 font-semibold text-slate-400">L</span>
                <input
                  id="bill"
                  type="number"
                  min="0.01"
                  step="0.01"
                  inputMode="decimal"
                  placeholder="Ej. 500.00"
                  value={bill}
                  onChange={handleBillChange}
                  className="w-full rounded-xl border border-slate-700 bg-slate-800 py-3.5 pl-10 pr-4 text-lg text-white outline-none transition placeholder:text-slate-500 focus:border-emerald-400 focus:ring-2 focus:ring-emerald-400/20"
                  required
                />
              </div>
            </div>

            <fieldset>
              <legend className="mb-3 block text-sm font-semibold text-slate-200">Porcentaje de propina</legend>
              <div className="grid grid-cols-3 gap-3">
                {percentages.map((percent) => (
                  <button
                    key={percent}
                    type="button"
                    onClick={() => handlePercentChange(percent)}
                    aria-pressed={tipPercent === percent}
                    className={`rounded-xl border py-3 font-bold transition focus:outline-none focus:ring-2 focus:ring-emerald-400/40 ${
                      tipPercent === percent
                        ? 'border-emerald-400 bg-emerald-400 text-slate-950 shadow-md shadow-emerald-400/10'
                        : 'border-slate-700 bg-slate-800 text-slate-200 hover:border-emerald-400/60 hover:bg-slate-700'
                    }`}
                  >
                    {percent}%
                  </button>
                ))}
              </div>
            </fieldset>

            <button
              type="submit"
              className="w-full rounded-xl bg-emerald-400 px-5 py-3.5 font-extrabold text-slate-950 shadow-lg shadow-emerald-400/10 transition hover:bg-emerald-300 focus:outline-none focus:ring-2 focus:ring-emerald-200 focus:ring-offset-2 focus:ring-offset-slate-900"
            >
              Calcular propina
            </button>
          </form>

          {calculated && validBill && (
            <section aria-live="polite" className="mt-6 rounded-2xl border border-emerald-400/30 bg-emerald-400/10 p-5">
              <p className="mb-4 text-center text-sm font-semibold uppercase tracking-wider text-emerald-300">Resultado</p>
              <div className="space-y-3">
                <div className="flex items-center justify-between gap-4 text-slate-300">
                  <span>Propina ({tipPercent}%)</span>
                  <strong className="text-lg text-white">{formatMoney(tipAmount)}</strong>
                </div>
                <div className="border-t border-emerald-400/20 pt-3">
                  <div className="flex items-center justify-between gap-4">
                    <span className="font-semibold text-slate-200">Total a pagar</span>
                    <strong className="text-2xl font-extrabold text-emerald-300">{formatMoney(totalAmount)}</strong>
                  </div>
                </div>
              </div>
            </section>
          )}

          <button
            type="button"
            onClick={resetCalculator}
            className="mt-4 w-full rounded-xl border border-slate-700 px-4 py-3 text-sm font-semibold text-slate-400 transition hover:border-slate-500 hover:text-white"
          >
            Limpiar
          </button>
        </div>

        <p className="mt-5 text-center text-xs text-slate-500">Desarrollado con React y Tailwind CSS</p>
      </section>
    </main>
  )
}