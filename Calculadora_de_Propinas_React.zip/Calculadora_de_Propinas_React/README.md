# Calculadora de Propinas (React + Tailwind CSS)

Aplicación para ingresar el monto de una cuenta, seleccionar una propina del 10%, 15% o 20%, y calcular la propina y el total final.

## Requisitos
- Node.js instalado
- npm

## Ejecutar en la computadora
1. Descomprimir el archivo ZIP.
2. Abrir la carpeta del proyecto en Visual Studio Code.
3. Abrir la terminal dentro de la carpeta.
4. Ejecutar:

   ```bash
   npm install
   npm run dev
   ```

5. Abrir en el navegador la dirección que indique Vite (normalmente `http://localhost:5173`).

## Crear versión de producción
```bash
npm run build
```

## Funcionalidades
- Campo para ingresar el monto de la cuenta en lempiras.
- Selección de 10%, 15% o 20% de propina.
- Botón para calcular.
- Muestra de la propina y del total a pagar.
- Botón para limpiar los campos y reiniciar.
- Diseño responsive con Tailwind CSS.
